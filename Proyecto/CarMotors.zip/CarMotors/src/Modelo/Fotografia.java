/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author ASUS
 */
import java.util.Date;
public class Fotografia {
    private String tipo;
    private String rutaArchivo;
    private String resolucion;
    private Date fechaTomada;
    public Fotografia() {}
    public String mostrarFoto(){ return null; }
    public void cambiarTipo(String nuevoTipo) {}
    public String obtenerDetalles(){ return null; }
    public boolean guardarFoto(String ruta){ return false; }
}