/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AbstarctFactory;

/**
 *
 * @author ASUS
 */
public class PolizaMapfre extends Poliza {
    public PolizaMapfre(long id, double costo, String cobertura) { super(id,costo,cobertura); }
}
