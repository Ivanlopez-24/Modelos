/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestDrive;

import Asesor.AsesorVehiculo;
import Modelo.Cliente;
import Modelo.Vehiculo;

/**
 *
 * @author ASUS
 */
public class TestDrive {
    private TestDriveSlot slot;
    private Vehiculo vehiculo;
    private Cliente cliente;
    private AsesorVehiculo asesor;
    public TestDrive() {}
    public void confirmar() {}
    public void cancelar() {}
    public String obtenerInfo(){ return null; }
}
