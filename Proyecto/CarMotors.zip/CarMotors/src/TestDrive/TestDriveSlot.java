/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestDrive;

/**
 *
 * @author ASUS
 */
import java.time.LocalDateTime;

public class TestDriveSlot {
    private LocalDateTime fechaHora;
    private boolean disponible;
    public TestDriveSlot() {}
    public void reservar() {}
    public void liberar() {}
    public boolean isDisponible(){ return disponible; }
}