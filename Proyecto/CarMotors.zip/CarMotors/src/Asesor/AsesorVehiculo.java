/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Asesor;

import Modelo.Vehiculo;

/**
 *
 * @author ASUS
 */
public class AsesorVehiculo extends Asesor {
    @Override public void asesorar() {}
    @Override public String obtenerDescripcion() { return null; }
    @Override public void mostrarDatosContacto() {}
    @Override public double calcularHonorarios(Vehiculo v) { return 0; }
}
