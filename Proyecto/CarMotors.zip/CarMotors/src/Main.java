/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import AbstarctFactory.*;
import Asesor.*;
import Banco.*;
import Bridge.*;
import Builder.*;
import Command.*;
import Historial.*;
import Mantenimiento.*;
import Modelo.*;
import Observer.*;
import Proxy.*;
import State.*;
import TestDrive.*;
/**
 *
 * @author ASUS
 */
public class Main {
    public static void main(String[] args) {

        System.out.println("=== PROYECTO UML INICIADO CORRECTAMENTE ===");

        // ---------------- BRIDGE ----------------
        Motor motor = new MotorGasolina();
        System.out.println("Motor creado: " + motor.getClass().getSimpleName());

        // ---------------- VEHICULO ----------------
        Vehiculo vehiculo = new Vehiculo();
        vehiculo.setMotor(motor);

        System.out.println("Vehículo creado con motor asignado.");

        // ---------------- BUILDER ----------------
        VehiculoBuilder builder = new SedanBuilder();
        builder.reset();
        builder.setDatosBasicos();
        Vehiculo vehiculoConstruido = builder.getVehiculo();

        System.out.println("Vehículo construido con Builder: " +
                vehiculoConstruido.getClass().getSimpleName());

        // ---------------- STATE ----------------
        EstadoVehiculo estado = new EstadoDisponible();
        System.out.println("Estado actual del vehículo: " + estado.nombreEstado());

        // ---------------- OBSERVER ----------------
        NotificadorVehiculo notificador = new NotificadorVehiculo();
        notificador.agregarObservador(new ClienteObservador());

        notificador.notificar(vehiculo, "Disponible");
        System.out.println("Notificación enviada a observadores.");

        // ---------------- COMMAND ----------------
        OperacionVehiculoCommand cmdVender = new VenderVehiculoCommand(vehiculo);
        GestorOperaciones gestor = new GestorOperaciones();
        gestor.ejecutar(cmdVender);

        System.out.println("Comando ejecutado (vender vehículo).");

        // ---------------- PROXY ----------------
        Usuario usuario = new Usuario();
        VehiculoProxy proxy = new VehiculoProxy(vehiculo, usuario);
        proxy.mostrarInformacion();

        System.out.println("Proxy instanciado.");

        // ---------------- FACTORY ----------------
        AseguradoraFactory factory = new SuraFactory();
        Poliza poliza = factory.crearPoliza();
        AsistenciaVial asistencia = factory.crearAsistencia();

        System.out.println("Factory creó póliza: " + poliza.getClass().getSimpleName());
        System.out.println("Factory creó asistencia: " + asistencia.getClass().getSimpleName());

        // ---------------- MANTENIMIENTO ----------------
        MantenimientoComponent mant = new MantenimientoSimple();
        mant.obtenerDescripcion();

        System.out.println("Mantenimiento básico instanciado.");

        // ---------------- TEST DRIVE ----------------
        TestDriveSlot slot = new TestDriveSlot();
        TestDrive testDrive = new TestDrive();

        System.out.println("Test Drive inicializado.");

        // ---------------- ASESOR / BANCO ----------------
        Asesor asesor = new AsesorVehiculo();
        EntidadBancaria banco = new EntidadBancaria();

        System.out.println("Asesor y banco instanciados.");

        // ---------------- HISTORIAL ----------------
        HistorialMantenimiento historial = new HistorialMantenimiento();
        System.out.println("Historial de mantenimiento creado.");

        System.out.println("\n=== TODO EL SISTEMA SE EJECUTÓ CORRECTAMENTE ===");
    }
}