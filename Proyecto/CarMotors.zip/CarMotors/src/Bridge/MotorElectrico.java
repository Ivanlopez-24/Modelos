/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bridge;

/**
 *
 * @author ASUS
 */
public class MotorElectrico extends Motor {
    public MotorElectrico() {}
    @Override public void acelerar() {}
    @Override public void encender() {}
    @Override public int getConsumo() { return 0; }
    @Override public int getPotencia() { return 0; }
}
